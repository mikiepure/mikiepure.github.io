# Win+R Launcher

Win+R Launcher is a utility software that "Run..." dialog can be used as a launcher.

## System Requirements

* .NET Framework 4.5.2

## Install

1. Unzip "WinRLauncher.zip".
2. Run "WinRLauncher.exe".

## Uninstall

1. Run "WinRLauncher.exe".
2. Select menu "Tool" > "Uninstall".
3. Press button "Yes" and "Yes".
